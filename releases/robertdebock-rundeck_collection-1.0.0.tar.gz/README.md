rundeck rundeck
===============

An [Ansible Collection](https://galaxy.ansible.com/docs/mazer/examples.html#installing-collections) to quickly get [Rundeck](https://www.rundeck.com/) up and running.
