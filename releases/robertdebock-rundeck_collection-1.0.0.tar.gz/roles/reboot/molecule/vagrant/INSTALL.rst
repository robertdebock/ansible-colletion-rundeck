*******
Vagrant driver installation guide
*******

Requirements
============

* Vagrant
* Virtualbox, Parallels, VMware Fusion, VMware Workstation or VMware Desktop
* python-vagrant

Install
=======

.. code-block:: bash

    $ sudo pip install python-vagrant
