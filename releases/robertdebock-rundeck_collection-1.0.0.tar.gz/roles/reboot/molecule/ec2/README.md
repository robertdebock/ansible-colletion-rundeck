# Amazon EC2

To test on Amazon elastic compute cloud (EC2), set this variable:

```
export EC2_REGION=eu-central-1
```

And save the credentials:
```
cat ~/.aws/credentials
[default]
aws_access_key_id=YOUR_KEY_ID
aws_secret_access_key=YOUR_ACCESS_KEY
```
